/**
 * Andrew Yoon
 * Justin Workman
 */
package cpsc2150.MyDeque;
import java.util.*;

public class ListDeque extends AbsDeque implements IDeque {
    /**
     * @Invariant: myQ.size() <= MAX_LENGTH
     * @Invariant: size >= 0
     * @Correspondent: size = myQ.size()
     * @Correspondent: self = myQ<MAX_LENGTH>
     */
    // this time store the deque in a list
    // myQ.get(0) is the front of the deque
    private List<Character> myQ;
    /**
     * @post myQ = ArrayList<Character> of size 100
     */
    ListDeque(){
        myQ = new ArrayList<Character>(MAX_LENGTH);
    }
    public void enqueue(Character x)
    {
        if(myQ.size() < MAX_LENGTH) {
            myQ.add(x);
        }
        else{
            System.out.println("Error: Deque is full");
        }
    }
    public Character dequeue() {
        char c;
        c = myQ.get(0);
        myQ.remove(0);
        return c;
    }

    public void inject(Character x) {
        if(myQ.size() < MAX_LENGTH) {
            myQ.add(0, x);
        }
        else{
            System.out.println("Error: Deque is full");
        }
    }
    public Character removeLast() {
        char c;
        c = myQ.get(myQ.size()-1);
        myQ.remove(myQ.size()-1);
        return c;
    }
    public int length() {
        return myQ.size();
    }
    public void clear() {
        myQ.clear();
    }
}

