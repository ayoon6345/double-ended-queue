/**
 * Andrew Yoon
 * Justin Workman
 */
package cpsc2150.MyDeque;
import java.util.*;

public class DequeApp {
    public static void main (String [] args) {
        IDeque q = null;

        System.out.println("Enter 1 for array implementation or 2 for List implementation\n");
        Scanner scanner = new Scanner(System.in);
        String input = " ";
    while(!input.equals('1') || !input.equals('2')){
            input = scanner.nextLine();
        if(input.equals("1")) {
            q = new ArrayDeque();
            printMenu(q);
            break;
        }
        else if(input.equals("2")) {
            q = new ListDeque();
            printMenu(q);
            break;
        }
        else{
            System.out.println("Enter 1 for array implementation or 2 for List implementation\n");
        }
    }
        System.out.print("\n");

    }//end of main

    /**
     * Present a numbered menu of options that asks the user which implementation they would like to use
     * @param q = IDeque deque object
     * @pre q != null
     */
    static void printMenu(IDeque q) {
        System.out.println("Select an option:");
        System.out.println("1. Add to the end of the Deque");
        System.out.println("2. Add to the front of the Deque");
        System.out.println("3. Remove from the front of the Deque");
        System.out.println("4. Remove from the end of the Deque");
        System.out.println("5. Peek from the front of the Deque");
        System.out.println("6. Peek from the end of the Deque");
        System.out.println("7. Insert to a position in the Deque");
        System.out.println("8. Remove from a position in the Deque");
        System.out.println("9. Get a position in the Deque");
        System.out.println("10. Get the length of the Deque");
        System.out.println("11. Clear the Deque");
        System.out.println("12. Quit");

        Integer input;
        char c;
        Scanner scanner = new Scanner(System.in);
        Scanner scanner1 = new Scanner(System.in);
        input = scanner.nextInt();
        String s;
        switch (input) {
            case 1:
                s = null;
                if(q.length() < 100) {
                    System.out.println("What character to enqueue to the end of the Deque?");
                    s = scanner1.nextLine();
                    c = s.charAt(0);
                    q.enqueue(c);

                    System.out.println("Deque is:\n" + q.toString() + "\n");
                }
                else {
                    System.out.println("Deque is full!");
                }
                printMenu(q);

            case 2:
                s = null;
                if(q.length() < 100) {
                    System.out.println("What character to inject to the front of the Deque?");
                    s = scanner1.nextLine();
                    c = s.charAt(0);
                    q.inject(c);
                    System.out.println("Deque is:\n" + q.toString() + "\n");
                }
                else {
                    System.out.println("Deque is full!");
                }
                printMenu(q);

            case 3:
                if (q.length() == 0) {
                    System.out.println("Deque is empty!");

                    System.out.println("Deque is:\n" + q.toString() + "\n");
                    printMenu(q);
                }

                System.out.println("Character at the front: " + q.dequeue());

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 4:
                if (q.length() == 0) {
                    System.out.println("Deque is empty!");

                    System.out.println("Deque is:\n" + q.toString() + "\n");
                    printMenu(q);
                }

                System.out.println("Character at the end: " + q.removeLast());

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 5:
                if (q.length() == 0) {
                    System.out.println("Deque is empty!");

                    System.out.println("Deque is:\n" + q.toString() + "\n");
                    printMenu(q);
                }

                System.out.println("Peek: " + q.peek());

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 6:
                if (q.length() == 0) {
                    System.out.println("Deque is empty!");

                    System.out.println("Deque is:\n" + q.toString() + "\n");
                    printMenu(q);
                }

                System.out.println("EndOfDeque: " + q.endOfDeque());

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 7:
                s = null;
                if (q.length() == 0) {
                    System.out.println("Deque is empty!");

                    System.out.println("Deque is:\n" + q.toString() + "\n");
                    printMenu(q);
                }

                System.out.println("What character to insert to the Deque?");
                s = scanner1.nextLine();
                while (s.length() > 1) {
                    System.out.println("Please insert only one character.");
                    s = scanner1.nextLine();
                }
                System.out.println("What position to insert in?");

                int whatPos7 = scanner.nextInt();
                while (whatPos7 < 1 || whatPos7 > q.length()) {
                    System.out.println("Not a valid position in the Deque!");
                    System.out.println("What position to insert in?");
                    whatPos7 = scanner.nextInt();
                }

                q.insert(s.charAt(0), whatPos7);

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 8:
                if (q.length() == 0) {
                    System.out.println("Deque is empty!");

                    System.out.println("Deque is:\n" + q.toString() + "\n");
                    printMenu(q);
                }

                System.out.println("What position to remove from the Deque?");

                int whatPos8 = scanner.nextInt();
                while (whatPos8 < 1 || whatPos8 > q.length()) {
                    System.out.println("Not a valid position in the Deque!");
                    System.out.println("What position to remove from the Deque?");
                    whatPos8 = scanner.nextInt();
                }
                System.out.println(q.remove(whatPos8) + " was at position " + whatPos8 + " in the Deque.");

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 9:
                if (q.length() == 0) {
                    System.out.println("Deque is empty!");

                    System.out.println("Deque is:\n" + q.toString() + "\n");
                    printMenu(q);
                }

                System.out.println("What position to get from the Deque?");

                int whatPos9 = scanner.nextInt();
                while (whatPos9 < 1 || whatPos9 > q.length()) {
                    System.out.println("Not a valid position in the Deque!");
                    System.out.println("What position to get from the Deque?");
                    whatPos9 = scanner.nextInt();
                }
                System.out.println(q.get(whatPos9) + " is at position " + whatPos9 + " in the Deque.");

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 10:
                System.out.println("Length of Deque: " + q.length());

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 11:
                q.clear();
                System.out.println("Deque is now empty!");

                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);

            case 12:
                java.lang.System.exit(0);

            default:
                System.out.println("Not a valid option!");
                System.out.println("Deque is:\n" + q.toString() + "\n");
                printMenu(q);
        }

    }

}