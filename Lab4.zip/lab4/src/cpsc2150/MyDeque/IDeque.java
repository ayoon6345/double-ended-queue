/**
 * Andrew Yoon
 * Justin Workman
 */
package cpsc2150.MyDeque;
import java.util.*;
/**
 * @defines:
 * size: Z+
 * A deque containing characters.
 * A deque is a data structure a double-ended queue that allows you
 * to insert and remove from both ends.
 * This deque is bounded by MAX_LENGTH
 *
 * Initialization Ensures:
 *      A deque containing blank characters and bounded by MAX_LENGTH
 * Constraints:
 *      0 < size <= MAX_LENGTH
 */
public interface IDeque {
    public static final int MAX_LENGTH = 100;

    /**
     * Adds x to the end of the deque
     * @param x Character to add to the end of the deque
     * @pre size < MAX_LENGTH
     * @post size = #size +1 AND character added to end of deque
     */
    public void enqueue(Character x);

    /**
     * removes and returns the Character at the front of the deque
     * @pre size > 0
     * @post size = #size -1 AND front character removed
     * @return removed character
     */
    public Character dequeue();

    /**
     * Adds x to the front of the deque
     * @param x Character to add to the front of the deque
     * @pre size < MAX_LENGTH
     * @post size = #size +1 AND character added to the front of the deque
     */
    public void inject(Character x);


    /**
     * removes and returns the Character at the end of the deque
     * @pre size > 0
     * @post size = #size -1 AND last character removed
     * @return removed Character
     */
    public Character removeLast();

    /**
     * returns the number of Characters in the deque
     * @post length = #size
     * @return number of characters in the deque
     */
    public int length();

    /**
     * clears the entire deque
     * @post size = 0
     */
    public void clear();

    /**
     * returns the character at the front of the deque but
     * does not remove  it  from  the deque
     *
     * @pre |deque| > 0
     * @pre size > 0
     * @post deque = #deque
     * @return character at the front of the deque
     */
    default Character peek() {
        char x = dequeue();
        inject(x);
        return x;
    }
    /**
     * returns the character at  the  end  of  the deque
     * but does not remove it from the deque.
     * @pre |deque| > 0
     * @pre size > 0
     * @post deque = #deque
     * @return character at the end of the deque
     */
    default Character endOfDeque() {
        char x = removeLast();
        enqueue(x);
        return x;
    }

    /**
     * inserts c at position pos in the deque. Pos index starts at 1, so the item at
     * the very front of the deque is pos 1.
     *
     * @param c = character being inserted
     * @param pos = position in the deque
     * @pre 1 <= pos <= size AND pos != null
     * @pre |deque| < size
     * @post deque = c is added at position pos to #deque
     */
    default void insert(Character c, int pos) {
        List<Character> RemovedChar;
        RemovedChar = new ArrayList<Character>(100);
        if(length() < MAX_LENGTH) {
            for (int i = pos - 1; i > 0; i--) {
                RemovedChar.add(0, dequeue());
            }
            inject(c);
            while (!RemovedChar.isEmpty()) {
                inject(RemovedChar.get(0));
                RemovedChar.remove(0);
            }
        }
    }

    /**
     * removes whatever character was in position pos in
     * the deque and returns it. Pos index starts at 1, so the item at the very front of the deque is pos 1.
     *
     * @param pos = integer of position to remove character from in the deque
     * @pre 1 <= pos <= size AND pos != null
     * @pre |deque| > 0
     * @post deque = character at position pos that was removed from #deque
     * @return character at position pos
     */
    default Character remove(int pos) {
        char c = ' ';
        List<Character> RemovedChar;
        RemovedChar = new ArrayList<Character>(100);
            for (int i = pos - 1; i > 0; i--) {
                RemovedChar.add(0, dequeue());
            }
            c = dequeue();
            while (!RemovedChar.isEmpty()) {
                inject(RemovedChar.get(0));
                RemovedChar.remove(0);
            }
        return c;
    }

    /**
     * returns whatever character was in position pos in the deque and without
     * removing it. Pos index starts at 1, so the item at the very front of the deque is pos 1.
     *
     * @param pos = integer of position to remove character from in the deque
     * @pre 1 <= pos <= size AND pos != null
     * @pre |deque| > 0
     * @post deque = #deque
     * @return character at position pos
     */
    default Character get(int pos) {
        char c;
        List<Character> RemovedChar;
        RemovedChar = new ArrayList<Character>(100);
        for(int i = pos-1; i > 0; i--) {
            RemovedChar.add(0, dequeue());
        }
        c = dequeue();
        inject(c);
        while(!RemovedChar.isEmpty()) {
            inject(RemovedChar.get(0));
            RemovedChar.remove(0);
        }
        return c;
    }
}