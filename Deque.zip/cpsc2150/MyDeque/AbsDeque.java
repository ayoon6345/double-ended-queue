/**
 * Andrew Yoon
 * Justin Workman
 */
package cpsc2150.MyDeque;

public abstract class AbsDeque implements IDeque{

    /**
     * Makes the deque into a string
     * @post: returns a String of the deque in this format: "<a, b>"
     */
    @Override
    public String toString(){
        String str = "";
        for(int i = 1; i <= length(); i++) {
            if (i > 1) {
                str += ", ";
            }
            str += get(i);
        }
        return ("<" + str + ">");
    }
}
