/**
 * Andrew Yoon
 * Justin Workman
 */
package cpsc2150.MyDeque;
import java.util.Arrays;

public class ArrayDeque extends AbsDeque implements IDeque{
    /**
     * @invariant myLength <= MAX_LENGTH
     * @Invariant: size >= 0
     * @Correspondent: size = myLength
     * @Correspondent: self = myQ[MAX_LENGTH]
     */
    // where the data is stored. myQ[0] is the front of the deque
    private Character[] myQ;

    // tracks how many items in the deque
    // also used to find the end of the deque
    private int myLength;
    /**
     * @post myQ = Character[100] AND myLength = 0
     */
     ArrayDeque(){
        myQ = new Character[MAX_LENGTH];
        myLength = 0;
    }
    //Adds character at the end of the deque if it's less that size 100 and increases length by 1
    public void enqueue(Character x){
         if(myLength < MAX_LENGTH) {
             myQ[myLength] = x;
             myLength++;
         }
         else{
             System.out.println("Error: Deque is full");
         }
    }
    //removes and returns front character then shifts all elements left by 1 then decreases length by 1
    public Character dequeue() {
        char c;
        int i = 0;
        c = myQ[0];
        myQ[0] = null;
        while(myQ[i+1] != myQ[myLength]){
            myQ[i] = myQ[i+1];
            i++;
        }
        myQ[i] = null;
        myLength--;
        return c;
    }
    //shifts all elements right by 1 then adds character at the beginning of the array then increases length by 1
    public void inject(Character x){
         if(myLength<MAX_LENGTH) {
             int j = myLength;
             while (j != -1) {
                 myQ[j + 1] = myQ[j];
                 j--;
             }
             myQ[0] = x;
             myLength++;
         }
         else {
             System.out.println("Error: Deque is full");
         }
    }
    //and returns character then decreases length by 1
    public Character removeLast(){
        char c;
        int j = myLength-1;
        c = myQ[j];
        myQ[j] = null;
        myLength--;
        return c;
    }

    //returns length of array
    public int length(){
         return myLength;
    }

    //clears array
    public void clear(){
         Arrays.fill(myQ,null);
         myLength = 0;
    }
}